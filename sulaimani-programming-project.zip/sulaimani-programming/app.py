from flask import Flask, render_template, request, jsonify
import ast, re
from pathlib import Path
app = Flask(__name__)
LESSONS = [
('Python','لغات البرمجة','لغة مناسبة للبداية والأتمتة.',"name = input('ما اسمك؟ ')\nprint(f'أهلاً {name}!')",'ابدأ بالمتغيرات والشروط والحلقات والدوال والقوائم والاستثناءات.'),
('HTML','تطوير الويب','هيكل صفحات الويب.','<!doctype html>\n<html lang="ar" dir="rtl"><h1>مرحباً بالعالم</h1></html>','تعلّم العناوين والفقرات والروابط والصور والنماذج.'),
('CSS','تطوير الويب','تنسيق صفحات الويب وألوانها.','body { direction: rtl; font-family: sans-serif; }\nh1 { color: #3764f5; }','تعلّم المحددات وFlexbox وGrid والتصميم المتجاوب.'),
('JavaScript','تطوير الويب','إضافة التفاعل إلى صفحات الويب.',"document.querySelector('button')?.addEventListener('click', () => alert('أهلاً!'));",'تعلّم المتغيرات والدوال والمصفوفات وDOM والأحداث.'),
('Kotlin / Android','تطبيقات الهاتف','أساسيات تطوير تطبيقات Android.','fun main() {\n  println("Hello!")\n}','ابدأ بـ Kotlin ثم واجهات Android وCompose.'),
('C / C++','لغات البرمجة','لغات للأداء العالي والأنظمة والألعاب.','#include <iostream>\nint main(){ std::cout << "Hello\\n"; return 0; }','تعلّم الأنواع والدوال والذاكرة وأساسيات البناء.'),
('بوتات Telegram','مشاريع عملية','أتمتة الردود والأوامر بشكل مسؤول.',"text = '/start'\nif text == '/start': print('أهلاً!')",'احفظ رمز البوت في متغير بيئة ولا تشاركه.'),
('الأمن السيبراني الأخلاقي','الأمن والحماية','تعلّم الحماية والاختبار بإذن واضح.',"checks = ['تحديث النظام', 'المصادقة الثنائية', 'نسخة احتياطية']\nfor x in checks: print(x)",'ابدأ بالشبكات وLinux وHTTP والتشفير وسجلات الأنظمة.'),
('حماية Android','الأمن والحماية','تقليل مخاطر التطبيقات والروابط المشبوهة.','# راجع المصدر والأذونات والتوقيع قبل تثبيت APK','حدّث الهاتف وتجنب التطبيقات مجهولة المصدر.'),
('حماية الراوتر','الشبكات','تقوية شبكة المنزل.','1. غيّر كلمة مرور الإدارة\n2. استخدم WPA2-AES أو WPA3\n3. حدّث البرنامج الثابت','اختبر فقط الشبكات التي تملكها أو لديك إذن لإدارتها.')]
@app.route('/')
def index(): return render_template('index.html', lessons=LESSONS)
@app.post('/api/python-check')
def python_check():
    code=(request.get_json(silent=True) or {}).get('code','')
    try: ast.parse(str(code)[:12000]); return jsonify(ok=True,message='الصياغة صحيحة. لم يتم تشغيل الكود.')
    except SyntaxError as e: return jsonify(ok=False,message=f'خطأ صياغة في السطر {e.lineno}: {e.msg}')
@app.post('/analyze')
def analyze():
    f=request.files.get('file')
    if not f: return jsonify(ok=False,message='اختر ملفاً أولاً.'),400
    if Path(f.filename).suffix.lower() not in {'.py','.txt','.html','.css','.js','.json','.xml','.md','.log'}: return jsonify(ok=True,level='غير مدعوم',message='النسخة التجريبية تقرأ ملفات نصية محددة فقط، ولا تفكك APK.')
    data=f.stream.read(512*1024+1)
    if len(data)>512*1024: return jsonify(ok=False,message='الملف أكبر من 512 KB.'),400
    s=data.decode('utf-8',errors='replace'); notes=[]
    if re.search(r"(?i)(api[_-]?key|password|passwd|secret|token)\s*[:=]\s*['\"][^'\"]{5,}",s): notes.append('قد توجد كلمة سر أو قيمة سرية مكتوبة مباشرة.')
    if re.search(r'(?i)(eval\s*\(|exec\s*\(|subprocess\.|os\.system\s*\()',s): notes.append('وجد استدعاء يستحق المراجعة اليدوية؛ وجوده لا يثبت الخبث.')
    if not notes: notes.append('لم تظهر مؤشرات بسيطة؛ هذا لا يثبت أن الملف آمن.')
    return jsonify(ok=True,level='فحص أولي غير حاسم',filename=f.filename,message=' '.join(notes),disclaimer='ليست هذه أداة مضاد فيروسات. لا تشغّل ملفات مجهولة.')
if __name__=='__main__': app.run(host='0.0.0.0',port=8080,debug=False)
