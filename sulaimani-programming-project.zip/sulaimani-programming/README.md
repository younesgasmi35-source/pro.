# سليماني للبرمجة
موقع عربي أولي لتعلم البرمجة والأمن الرقمي المسؤول.

## تشغيله في Termux
```bash
pkg install python
cd sulaimani-programming
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
ثم افتح http://127.0.0.1:8080

## النشر
هذا تطبيق Flask؛ GitHub Pages لا يشغّل Python. ارفع المستودع إلى GitHub ثم اربطه باستضافة تدعم Python مثل Render، واستخدم أمر التشغيل `gunicorn app:app`.

## حدود الأمان
فحص الملفات تجريبي للملفات النصية فقط ولا يثبت أن الملف آمن أو خبيث. لا ترفع أسراراً أو ملفات خاصة.
